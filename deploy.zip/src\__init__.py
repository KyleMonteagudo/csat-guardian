# =============================================================================
# CSAT Guardian - Source Package
# =============================================================================
# This is the main source package for the CSAT Guardian application.
# =============================================================================

__version__ = "0.1.0"
__author__ = "CSS Escalations Team"
__description__ = "Customer Satisfaction Guardian - Proactive CSAT Risk Detection"
